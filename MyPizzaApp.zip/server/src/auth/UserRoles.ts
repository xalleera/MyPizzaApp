export type UserRoles = {
  roles: string[];
};
