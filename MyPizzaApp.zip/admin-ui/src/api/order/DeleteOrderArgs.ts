import { OrderWhereUniqueInput } from "./OrderWhereUniqueInput";

export type DeleteOrderArgs = {
  where: OrderWhereUniqueInput;
};
