export type OrderWhereUniqueInput = {
  id: string;
};
