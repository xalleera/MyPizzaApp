import { OrderWhereUniqueInput } from "../order/OrderWhereUniqueInput";

export type OrderCreateNestedManyWithoutDrinksInput = {
  connect?: Array<OrderWhereUniqueInput>;
};
