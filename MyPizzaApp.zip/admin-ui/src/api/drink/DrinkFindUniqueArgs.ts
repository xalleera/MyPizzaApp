import { DrinkWhereUniqueInput } from "./DrinkWhereUniqueInput";

export type DrinkFindUniqueArgs = {
  where: DrinkWhereUniqueInput;
};
