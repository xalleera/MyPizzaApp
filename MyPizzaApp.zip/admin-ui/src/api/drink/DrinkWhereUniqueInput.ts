export type DrinkWhereUniqueInput = {
  id: string;
};
