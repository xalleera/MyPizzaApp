import { DrinkCreateInput } from "./DrinkCreateInput";

export type CreateDrinkArgs = {
  data: DrinkCreateInput;
};
