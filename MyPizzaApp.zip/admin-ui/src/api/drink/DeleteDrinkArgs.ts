import { DrinkWhereUniqueInput } from "./DrinkWhereUniqueInput";

export type DeleteDrinkArgs = {
  where: DrinkWhereUniqueInput;
};
