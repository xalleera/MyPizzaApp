import { ProductCreateInput } from "./ProductCreateInput";

export type CreateProductArgs = {
  data: ProductCreateInput;
};
