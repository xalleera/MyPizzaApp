import { ProductWhereUniqueInput } from "./ProductWhereUniqueInput";

export type DeleteProductArgs = {
  where: ProductWhereUniqueInput;
};
