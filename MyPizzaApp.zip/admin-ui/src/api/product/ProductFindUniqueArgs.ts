import { ProductWhereUniqueInput } from "./ProductWhereUniqueInput";

export type ProductFindUniqueArgs = {
  where: ProductWhereUniqueInput;
};
