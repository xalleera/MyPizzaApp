import { OrderWhereUniqueInput } from "../order/OrderWhereUniqueInput";

export type OrderCreateNestedManyWithoutCustomersInput = {
  connect?: Array<OrderWhereUniqueInput>;
};
