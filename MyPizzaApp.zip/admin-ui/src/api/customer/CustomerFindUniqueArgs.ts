import { CustomerWhereUniqueInput } from "./CustomerWhereUniqueInput";

export type CustomerFindUniqueArgs = {
  where: CustomerWhereUniqueInput;
};
