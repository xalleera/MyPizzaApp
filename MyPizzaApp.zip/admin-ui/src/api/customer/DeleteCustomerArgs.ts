import { CustomerWhereUniqueInput } from "./CustomerWhereUniqueInput";

export type DeleteCustomerArgs = {
  where: CustomerWhereUniqueInput;
};
