import { AddressCreateInput } from "./AddressCreateInput";

export type CreateAddressArgs = {
  data: AddressCreateInput;
};
