import { AddressWhereUniqueInput } from "./AddressWhereUniqueInput";

export type AddressFindUniqueArgs = {
  where: AddressWhereUniqueInput;
};
