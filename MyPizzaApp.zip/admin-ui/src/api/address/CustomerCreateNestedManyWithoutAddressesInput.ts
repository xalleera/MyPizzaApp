import { CustomerWhereUniqueInput } from "../customer/CustomerWhereUniqueInput";

export type CustomerCreateNestedManyWithoutAddressesInput = {
  connect?: Array<CustomerWhereUniqueInput>;
};
