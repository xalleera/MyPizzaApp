export class BooleanNullableFilter {
  equals?: boolean | null;
  not?: boolean | null;
}
