export enum EnumRoles {
  User = "user",
  Admin = "admin",
}
